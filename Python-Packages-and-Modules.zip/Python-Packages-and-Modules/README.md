# Python Packages and Modules

## Aim
To create Python packages and import modules from packages.

## Description
This project demonstrates Python packages, modules, and code reusability.

## Modules
- `arithmetic.py`: addition and subtraction
- `geometry.py`: area and perimeter of a circle

## How to Run
Run this command from the project folder:

```bash
python main.py
```

## Expected Output
```text
Sum: 15
Difference: 5
Area of Circle: 153.86
Perimeter of Circle: 43.96
```

## Language
Python
