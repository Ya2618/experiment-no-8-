from MyPackage import arithmetic, geometry

# Arithmetic operations
sum_result = arithmetic.add(10, 5)
diff_result = arithmetic.subtract(10, 5)

# Geometry operations
area = geometry.area_of_circle(7)
perimeter = geometry.perimeter_of_circle(7)

# Display results
print("Sum:", sum_result)
print("Difference:", diff_result)
print("Area of Circle:", area)
print("Perimeter of Circle:", perimeter)
